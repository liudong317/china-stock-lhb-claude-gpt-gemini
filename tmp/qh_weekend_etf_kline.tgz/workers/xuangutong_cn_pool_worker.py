#!/usr/bin/env python3
"""A'：选股通涨停池/解读/情绪 → Redis + 日冷库。

主源：flash-api.xuangubao.com.cn（无需登录 Cookie）
写入：
  Redis  qh:cn:limit_up:today
         qh:cn:pool:{pool_name}
         qh:cn:sentiment
  冷库   data/raw/cn_limit_up/YYYY-MM-DD.json
         data/raw/cn_sentiment/YYYY-MM-DD.json

用法：
  REDIS_URL=redis://127.0.0.1:6379/0 python3 workers/xuangutong_cn_pool_worker.py --once
  REDIS_URL=redis://127.0.0.1:6379/0 python3 workers/xuangutong_cn_pool_worker.py --interval 30
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from lib.trading_session import cn_session_ymd, should_pull  # noqa: E402

UA = "Mozilla/5.0 (compatible; qinghong-xgt-worker/1.0)"
HEADERS = {
    "User-Agent": UA,
    "Referer": "https://xuangutong.com.cn/dingpan",
    "Origin": "https://xuangutong.com.cn",
    "Accept": "application/json",
}
POOLS = (
    "limit_up",
    "yesterday_limit_up",
    "limit_up_broken",
    "limit_down",
    "super_stock",
)
LIMIT_UP_DIR = ROOT / "data" / "raw" / "cn_limit_up"
SENT_DIR = ROOT / "data" / "raw" / "cn_sentiment"


def http_get(url: str) -> dict:
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=25) as resp:
        return json.loads(resp.read().decode("utf-8", "ignore"))


def normalize_item(raw: dict) -> dict:
    """统一对外字段；保留 surge_reason 解读。"""
    sr = raw.get("surge_reason") or {}
    plates = sr.get("related_plates") or []
    return {
        "symbol": raw.get("symbol"),
        "name": raw.get("stock_chi_name"),
        "price": raw.get("price"),
        "change_percent": raw.get("change_percent"),
        "limit_up_days": raw.get("limit_up_days"),
        "first_limit_up": raw.get("first_limit_up"),
        "last_limit_up": raw.get("last_limit_up"),
        "break_limit_up_times": raw.get("break_limit_up_times"),
        "turnover_ratio": raw.get("turnover_ratio"),
        "buy_lock_volume_ratio": raw.get("buy_lock_volume_ratio"),
        "sell_lock_volume_ratio": raw.get("sell_lock_volume_ratio"),
        "m_days_n_boards_days": raw.get("m_days_n_boards_days"),
        "m_days_n_boards_boards": raw.get("m_days_n_boards_boards"),
        "stock_type": raw.get("stock_type"),
        "is_new_stock": raw.get("is_new_stock"),
        "limit_timeline": raw.get("limit_timeline"),
        "surge_reason": {
            "text": sr.get("stock_reason"),
            "plates": [
                {
                    "plate_id": p.get("plate_id"),
                    "plate_name": p.get("plate_name"),
                    "plate_reason": p.get("plate_reason"),
                }
                for p in plates
                if isinstance(p, dict)
            ],
        },
        "raw_surge_reason": sr if sr else None,
    }


def fetch_pool(pool_name: str) -> list[dict]:
    url = f"https://flash-api.xuangubao.com.cn/api/pool/detail?pool_name={pool_name}"
    j = http_get(url)
    if j.get("code") not in (20000, 200, 0, None):
        raise RuntimeError(f"pool {pool_name} code={j.get('code')} msg={j.get('message')}")
    data = j.get("data") or []
    if not isinstance(data, list):
        return []
    return [normalize_item(x) for x in data if isinstance(x, dict)]


def fetch_sentiment() -> dict:
    pcp = http_get("https://flash-api.xuangubao.com.cn/api/market_indicator/pcp_distribution")
    temp = http_get(
        "https://flash-api.xuangubao.com.cn/api/market_indicator/line?fields=market_temperature"
    )
    rise = http_get(
        "https://flash-api.xuangubao.com.cn/api/market_indicator/line?fields=rise_count,fall_count"
    )
    lu = http_get(
        "https://flash-api.xuangubao.com.cn/api/market_indicator/line?fields=limit_up_count,limit_down_count"
    )
    broken = http_get(
        "https://flash-api.xuangubao.com.cn/api/market_indicator/line?fields=limit_up_broken_count,limit_up_broken_ratio"
    )

    def last_line(j: dict):
        data = j.get("data")
        if isinstance(data, list) and data:
            return data[-1]
        return data

    return {
        "pcp_distribution": pcp.get("data"),
        "market_temperature": last_line(temp),
        "rise_fall": last_line(rise),
        "limit_up_down_count": last_line(lu),
        "limit_up_broken": last_line(broken),
        "src": "xuangutong.flash-api",
        "ts": int(time.time()),
        "asof_date": cn_session_ymd(),
    }


def redis_client(url: str):
    import redis  # type: ignore

    return redis.Redis.from_url(url, decode_responses=True)


def atomic_write(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    tmp.replace(path)


def persist_cold(day: str, pools: dict[str, list], sentiment: dict) -> None:
    payload = {
        "date": day,
        "src": "xuangutong.flash-api",
        "ts": int(time.time()),
        "pools": {k: {"count": len(v), "items": v} for k, v in pools.items()},
        "sentiment": sentiment,
    }
    atomic_write(LIMIT_UP_DIR / f"{day}.json", payload)
    atomic_write(
        SENT_DIR / f"{day}.json",
        {"date": day, "src": "xuangutong.flash-api", "ts": int(time.time()), "data": sentiment},
    )


def write_redis(r, pools: dict[str, list], sentiment: dict, ttl: int, day: str) -> None:
    pipe = r.pipeline()
    meta = {"date": day, "src": "xuangutong.flash-api", "ts": int(time.time())}
    for name, items in pools.items():
        body = {"date": day, "pool": name, "count": len(items), "items": items, **meta}
        pipe.set(f"qh:cn:pool:{name}", json.dumps(body, ensure_ascii=False, separators=(",", ":")), ex=ttl)
        if name == "limit_up":
            pipe.set(
                "qh:cn:limit_up:today",
                json.dumps(body, ensure_ascii=False, separators=(",", ":")),
                ex=ttl,
            )
    pipe.set(
        "qh:cn:sentiment",
        json.dumps(sentiment, ensure_ascii=False, separators=(",", ":")),
        ex=ttl,
    )
    pipe.set(
        "qh:cn:pool:_meta",
        json.dumps({**meta, "pools": {k: len(v) for k, v in pools.items()}}, ensure_ascii=False),
        ex=ttl,
    )
    pipe.execute()


def run_once(r, ttl: int, force: bool) -> None:
    ok_gate, reason = should_pull("cn")
    if not ok_gate and not force:
        # 盘后/休市仍拉池写冷库（涨停解读复盘用）；仅打印闸门提示
        print(f"gate note: {reason} (continue for cold pool)", flush=True)
    # 休市日写入上一交易日，避免把周五残留标成周六/周日
    day = cn_session_ymd()
    pools: dict[str, list] = {}
    for name in POOLS:
        try:
            pools[name] = fetch_pool(name)
            print(f"OK pool {name} n={len(pools[name])}", flush=True)
        except Exception as e:
            print(f"FAIL pool {name}: {e}", flush=True)
            pools[name] = []
        time.sleep(0.2)
    sentiment = fetch_sentiment()
    print(
        f"OK sentiment temp={((sentiment.get('market_temperature') or {}).get('market_temperature'))}",
        flush=True,
    )
    if r is not None:
        write_redis(r, pools, sentiment, ttl, day)
    persist_cold(day, pools, sentiment)
    print(f"wrote {'redis+' if r is not None else ''}cold day={day} limit_up={len(pools.get('limit_up') or [])}", flush=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--interval", type=float, default=30.0)
    ap.add_argument("--ttl", type=int, default=600)
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--force", action="store_true", help="忽略交易日闸门")
    ap.add_argument("--no-redis", action="store_true", help="只写日冷库，不写 Redis")
    ap.add_argument("--redis", default=os.environ.get("REDIS_URL", "redis://127.0.0.1:6379/0"))
    args = ap.parse_args()

    r = None
    if not args.no_redis:
        r = redis_client(args.redis)
        r.ping()
    print(f"xgt pool worker start redis={'off' if args.no_redis else args.redis}", flush=True)

    while True:
        try:
            run_once(r, args.ttl, args.force)
        except Exception as e:
            print(f"round_fail {e}", flush=True)
        if args.once:
            break
        time.sleep(max(5.0, args.interval))


if __name__ == "__main__":
    main()
