#!/usr/bin/env python3
"""选股通：板块排名 + 个股资金流 → Redis 热缓存 + 日冷库。

逻辑（必须遵守）：
  1) 每轮优先写 Redis（近实时），客户 API 只读 Redis/冷库，不透传爬源
  2) 同轮覆盖写日冷库（复盘/盘后回落）；热数据 TTL 续期，盘中以 Redis 为准
  3) 资金流：每轮刷「热池」（涨停池+板块龙头+cn_hot），并轮转全 A 补全冷库

Redis：
  qh:cn:sectors                 板块榜整包
  qh:cn:moneyflow:{SYM}         单票资金流
  qh:cn:moneyflow:_meta
冷库：
  data/raw/cn_sectors/YYYY-MM-DD.json
  data/raw/cn_moneyflow/YYYY-MM-DD.json   （当日累计 map，持续覆盖）

用法：
  REDIS_URL=redis://127.0.0.1:6379/0 python3 workers/xuangutong_cn_sector_flow_worker.py --once --force
  REDIS_URL=redis://127.0.0.1:6379/0 python3 workers/xuangutong_cn_sector_flow_worker.py --interval 30
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from lib.trading_session import cn_session_ymd, should_pull  # noqa: E402

UA = "Mozilla/5.0 (compatible; qinghong-xgt-sector-flow/1.0)"
HEADERS = {
    "User-Agent": UA,
    "Referer": "https://xuangutong.com.cn/dingpan",
    "Origin": "https://xuangutong.com.cn",
    "Accept": "application/json",
}
FLASH = "https://flash-api.xuangubao.com.cn"
DDC = "https://api-ddc-wscn.xuangubao.com.cn"
LIST_TXT = ROOT / "data" / "lists" / "cn_ashare.txt"
HOT_TXT = ROOT / "data" / "lists" / "cn_hot.txt"
SECTOR_DIR = ROOT / "data" / "raw" / "cn_sectors"
FLOW_DIR = ROOT / "data" / "raw" / "cn_moneyflow"

# 对客验票/龙头：每轮强制进资金流热池（写 Redis TTL），避免只靠轮转冷库
ENSURE_HOT = [
    "600519.SS",
    "000001.SZ",
    "300750.SZ",
    "000858.SZ",
    "601318.SS",
    "000333.SZ",
    "600036.SS",
    "002594.SZ",
]

# 轮转游标（进程内）
_ROTATE_IDX = 0


def http_get(url: str, timeout: float = 25.0) -> dict:
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", "ignore"))


def redis_client(url: str):
    import redis  # type: ignore

    return redis.Redis.from_url(url, decode_responses=True)


def atomic_write(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    tmp.replace(path)


def _norm_sym(raw: str) -> str:
    s = (raw or "").strip().upper().replace("SH", "SS")
    if not s:
        return s
    if "." in s:
        return s
    if s.startswith(("5", "6", "9")):
        return f"{s}.SS"
    return f"{s}.SZ"


def _stock_brief(raw: dict) -> dict:
    return {
        "symbol": _norm_sym(str(raw.get("symbol") or "")),
        "name": raw.get("name") or raw.get("stock_chi_name"),
        "change_percent": raw.get("change_percent") if raw.get("change_percent") is not None else raw.get("mtm"),
        "price_change": raw.get("price_change"),
    }


def _plate_from_incdec(raw: dict) -> dict:
    stocks = [_stock_brief(x) for x in (raw.get("stocks") or []) if isinstance(x, dict)]
    return {
        "plate_id": raw.get("plate_id"),
        "plate_name": raw.get("plate_name"),
        "change_percent": raw.get("pcp"),
        "stocks": stocks,
    }


def _plate_from_top(raw: dict, *, rising: bool) -> dict:
    key = "led_rising_stocks" if rising else "led_falling_stocks"
    led = ((raw.get(key) or {}).get("items")) or []
    return {
        "plate_id": raw.get("plate_id"),
        "plate_name": raw.get("plate_name"),
        "change_percent": raw.get("core_avg_pcp"),
        "stocks": [_stock_brief(x) for x in led if isinstance(x, dict)],
    }


def fetch_sectors(limit: int = 50) -> dict:
    up = http_get(f"{FLASH}/api/plate/incdec?move_type=1&limit={limit}")
    dn = http_get(f"{FLASH}/api/plate/incdec?move_type=2&limit={limit}")
    top = http_get(f"{FLASH}/api/stage2/plate/top_info?count={min(limit, 30)}&fields=all")
    themes = http_get(f"{FLASH}/api/surge_stock/plates")

    def items(j: dict) -> list:
        d = j.get("data")
        if isinstance(d, dict):
            return d.get("items") or []
        return d if isinstance(d, list) else []

    top_d = top.get("data") or {}
    theme_items = []
    td = themes.get("data") or {}
    for x in td.get("items") or []:
        if not isinstance(x, dict):
            continue
        theme_items.append(
            {
                "plate_id": x.get("id"),
                "plate_name": x.get("name"),
                "description": x.get("description"),
            }
        )

    return {
        "rise": [_plate_from_incdec(x) for x in items(up) if isinstance(x, dict)],
        "fall": [_plate_from_incdec(x) for x in items(dn) if isinstance(x, dict)],
        "top": [_plate_from_top(x, rising=True) for x in (top_d.get("top_plate_info") or []) if isinstance(x, dict)],
        "bottom": [
            _plate_from_top(x, rising=False) for x in (top_d.get("bottom_plate_info") or []) if isinstance(x, dict)
        ],
        "themes": theme_items,
        "src": "xuangutong.flash-api",
        "ts": int(time.time()),
        "asof_date": cn_session_ymd(),
    }


def _normalize_flow(sym: str, raw: dict) -> dict:
    """单票资金流统一字段（数值保持上游原单位）。"""
    return {
        "symbol": _norm_sym(sym or str(raw.get("prod_code") or "")),
        "date": raw.get("date") or cn_session_ymd(),
        "main_in": raw.get("main_in"),
        "main_out": raw.get("main_out"),
        "net_inflow": raw.get("net_inflow"),
        "super_big_in": raw.get("super_big_in"),
        "super_big_out": raw.get("super_big_out"),
        "net_super": raw.get("net_super"),
        "big_in": raw.get("big_in"),
        "big_out": raw.get("big_out"),
        "net_big": raw.get("net_big"),
        "medium_in": raw.get("medium_in"),
        "medium_out": raw.get("medium_out"),
        "net_medium": raw.get("net_medium"),
        "small_in": raw.get("small_in"),
        "small_out": raw.get("small_out"),
        "net_small": raw.get("net_small"),
        "retail_in": raw.get("retail_in"),
        "retail_out": raw.get("retail_out"),
        "src": "xuangutong.fundflow",
        "ts": int(time.time()),
        "upstream_ts": raw.get("timestamp"),
    }


_BATCH_FLOW_KEYS = (
    "main_in",
    "main_out",
    "retail_in",
    "retail_out",
    "net_inflow",
    "super_big_in",
    "super_big_out",
    "net_super",
    "big_in",
    "big_out",
    "net_big",
    "medium_in",
    "medium_out",
    "net_medium",
    "small_in",
    "small_out",
    "net_small",
)


def _parse_batch_row(sym: str, row) -> Optional[dict]:
    """batch：{fund_flow:[[code,date,main_in,...net_small,ts],...]} 或已展开 dict。"""
    if isinstance(row, dict) and "main_in" in row:
        return _normalize_flow(sym, row)
    if isinstance(row, dict) and isinstance(row.get("fund_flow"), list) and row["fund_flow"]:
        last = row["fund_flow"][-1]
        if isinstance(last, list) and len(last) >= 19:
            raw = {
                "prod_code": last[0] or sym,
                "date": last[1],
                "timestamp": last[19] if len(last) > 19 else None,
            }
            for i, k in enumerate(_BATCH_FLOW_KEYS):
                raw[k] = last[2 + i] if len(last) > 2 + i else None
            return _normalize_flow(sym, raw)
    return None


def fetch_fundflow_batch(syms: list[str]) -> dict[str, dict]:
    """批量拉资金流；解析失败的个股再单拉。"""
    out: dict[str, dict] = {}
    if not syms:
        return out
    uniq = []
    seen = set()
    for s in syms:
        n = _norm_sym(s)
        if n and n not in seen:
            seen.add(n)
            uniq.append(n)
    q = urllib.parse.urlencode({"prod_codes": ",".join(uniq)})
    j = http_get(f"{DDC}/market/fundflow/batch?{q}", timeout=40)
    if j.get("code") not in (20000, 200, 0, None):
        raise RuntimeError(f"fundflow batch code={j.get('code')} msg={j.get('message')}")
    data = j.get("data") or {}
    need_single: list[str] = []
    if isinstance(data, dict):
        for sym, row in data.items():
            parsed = _parse_batch_row(sym, row)
            if parsed:
                out[_norm_sym(sym)] = parsed
            else:
                need_single.append(_norm_sym(sym))
        for s in uniq:
            if s not in out and s not in need_single:
                need_single.append(s)
    else:
        need_single = list(uniq)

    for sym in need_single:
        try:
            one = http_get(f"{DDC}/market/fundflow?prod_code={urllib.parse.quote(sym)}", timeout=20)
            items = ((one.get("data") or {}).get("items")) or []
            if items and isinstance(items[0], dict):
                out[sym] = _normalize_flow(sym, items[0])
            time.sleep(0.05)
        except Exception as e:
            print(f"FAIL fundflow {sym}: {e}", flush=True)
    return out


def load_ashare() -> list[str]:
    if not LIST_TXT.exists():
        return []
    return [_norm_sym(ln) for ln in LIST_TXT.read_text(encoding="utf-8").splitlines() if ln.strip()]


def load_hot_file() -> list[str]:
    if not HOT_TXT.exists():
        return []
    return [_norm_sym(ln) for ln in HOT_TXT.read_text(encoding="utf-8").splitlines() if ln.strip()]


def collect_priority_syms(r, sectors: dict) -> list[str]:
    """热池：ENSURE + cn_hot + 涨停 Redis + 板块龙头。盘中靠 Redis TTL 续期保实时。"""
    out: list[str] = []
    seen: set[str] = set()

    def add(s: str) -> None:
        n = _norm_sym(s)
        if n and n not in seen:
            seen.add(n)
            out.append(n)

    for s in ENSURE_HOT:
        add(s)
    for lst in load_hot_file():
        add(lst)

    if r is not None:
        for key in ("qh:cn:limit_up:today", "qh:cn:pool:super_stock", "qh:cn:pool:limit_up_broken"):
            try:
                raw = r.get(key)
                if not raw:
                    continue
                body = json.loads(raw)
                for it in body.get("items") or []:
                    if isinstance(it, dict):
                        add(str(it.get("symbol") or ""))
            except Exception:
                pass

    for bucket in ("rise", "fall", "top", "bottom"):
        for plate in sectors.get(bucket) or []:
            for st in plate.get("stocks") or []:
                if isinstance(st, dict):
                    add(str(st.get("symbol") or ""))
    return out


def next_rotate_batch(all_syms: list[str], batch: int) -> list[str]:
    global _ROTATE_IDX
    if not all_syms or batch <= 0:
        return []
    n = len(all_syms)
    start = _ROTATE_IDX % n
    end = start + batch
    if end <= n:
        chunk = all_syms[start:end]
    else:
        chunk = all_syms[start:] + all_syms[: end % n]
    _ROTATE_IDX = (start + batch) % n
    return chunk


def write_sectors_redis(r, sectors: dict, ttl: int, day: str) -> None:
    body = {**sectors, "date": day}
    r.set("qh:cn:sectors", json.dumps(body, ensure_ascii=False, separators=(",", ":")), ex=ttl)


def write_flow_redis(r, flows: dict[str, dict], ttl: int, day: str) -> None:
    if not flows:
        return
    pipe = r.pipeline()
    for sym, row in flows.items():
        pipe.set(
            f"qh:cn:moneyflow:{sym}",
            json.dumps(row, ensure_ascii=False, separators=(",", ":")),
            ex=ttl,
        )
    pipe.set(
        "qh:cn:moneyflow:_meta",
        json.dumps(
            {"date": day, "ts": int(time.time()), "src": "xuangutong.fundflow", "count": len(flows)},
            ensure_ascii=False,
        ),
        ex=ttl,
    )
    pipe.execute()


def persist_sectors_cold(day: str, sectors: dict) -> None:
    atomic_write(SECTOR_DIR / f"{day}.json", {**sectors, "date": day})


def persist_flow_cold(day: str, flows: dict[str, dict]) -> None:
    """日冷库为累计 map：读出合并再写回，保证全 A 轮转能攒齐。"""
    path = FLOW_DIR / f"{day}.json"
    merged: dict[str, dict] = {}
    if path.exists():
        try:
            old = json.loads(path.read_text(encoding="utf-8"))
            items = old.get("items") or {}
            if isinstance(items, dict):
                merged.update(items)
        except Exception:
            pass
    merged.update(flows)
    atomic_write(
        path,
        {
            "date": day,
            "src": "xuangutong.fundflow",
            "ts": int(time.time()),
            "count": len(merged),
            "items": merged,
        },
    )


def run_once(
    r,
    *,
    ttl: int,
    force: bool,
    plate_limit: int,
    flow_batch: int,
    rotate_batch: int,
    skip_flow: bool,
) -> None:
    ok_gate, reason = should_pull("cn")
    if not ok_gate and not force:
        print(f"gate note: {reason} (continue; refresh hot+cold)", flush=True)

    day = cn_session_ymd()
    sectors = fetch_sectors(limit=plate_limit)
    print(
        f"OK sectors rise={len(sectors.get('rise') or [])} fall={len(sectors.get('fall') or [])} "
        f"top={len(sectors.get('top') or [])} themes={len(sectors.get('themes') or [])}",
        flush=True,
    )
    if r is not None:
        write_sectors_redis(r, sectors, ttl, day)
    persist_sectors_cold(day, sectors)

    if skip_flow:
        print("skip moneyflow", flush=True)
        return

    priority = collect_priority_syms(r, sectors)
    rotate = next_rotate_batch(load_ashare(), rotate_batch)
    # 本轮目标：热池全量 + 一轮轮转；控制单轮请求量
    want: list[str] = []
    seen: set[str] = set()
    for s in priority + rotate:
        if s not in seen:
            seen.add(s)
            want.append(s)

    flows: dict[str, dict] = {}
    for i in range(0, len(want), flow_batch):
        chunk = want[i : i + flow_batch]
        try:
            part = fetch_fundflow_batch(chunk)
            flows.update(part)
            print(f"OK fundflow batch n={len(part)}/{len(chunk)}", flush=True)
        except Exception as e:
            print(f"FAIL fundflow batch: {e}", flush=True)
        time.sleep(0.15)

    if r is not None:
        write_flow_redis(r, flows, ttl, day)
    if flows:
        persist_flow_cold(day, flows)
    print(
        f"wrote {'redis+' if r is not None else ''}cold sectors+flow day={day} "
        f"flow_hot={len(priority)} flow_round={len(flows)} rotate_i={_ROTATE_IDX}",
        flush=True,
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--interval", type=float, default=30.0)
    ap.add_argument("--ttl", type=int, default=600, help="Redis TTL 秒；盘中靠续期保热")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--no-redis", action="store_true")
    ap.add_argument("--skip-flow", action="store_true", help="只采板块")
    ap.add_argument("--plate-limit", type=int, default=50)
    ap.add_argument("--flow-batch", type=int, default=80, help="选股通 batch 单次股票数")
    ap.add_argument("--rotate-batch", type=int, default=200, help="每轮额外轮转全 A 数量")
    ap.add_argument("--redis", default=os.environ.get("REDIS_URL", "redis://127.0.0.1:6379/0"))
    args = ap.parse_args()

    r = None
    if not args.no_redis:
        r = redis_client(args.redis)
        r.ping()
    print(
        f"xgt sector/flow worker start redis={'off' if args.no_redis else args.redis} "
        f"ttl={args.ttl} rotate={args.rotate_batch}",
        flush=True,
    )

    while True:
        try:
            run_once(
                r,
                ttl=args.ttl,
                force=args.force,
                plate_limit=args.plate_limit,
                flow_batch=args.flow_batch,
                rotate_batch=args.rotate_batch,
                skip_flow=args.skip_flow,
            )
        except Exception as e:
            print(f"round_fail {e}", flush=True)
        if args.once:
            break
        time.sleep(max(5.0, args.interval))


if __name__ == "__main__":
    main()
