#!/usr/bin/env python3
"""大 A 报价预采 → Redis。API 只读缓存，不透传爬源。

源优先级（新加坡 2026-07-29 实测）：
1) 选股通 api-ddc-wscn.xuangubao.com.cn/market/real（主源；SG 可达，单批≤500）
2) TickFlow REST（备源；免费档限流重）
3) quotes.sina.cn K 线末日 / 东财 / hq.sinajs（国内可用；SG 常挂）
4) 冷库末日灌热（保底，src=cold.seed）

用法：
  REDIS_URL=redis://127.0.0.1:6379/0 python3 workers/sina_cn_quote_worker.py --hot 500 --batch 200 --prefer xuangutong
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from lib.trading_session import should_pull  # noqa: E402

LIST_TXT = ROOT / "data" / "lists" / "cn_ashare.txt"
HOT_TXT = ROOT / "data" / "lists" / "cn_hot.txt"
CN_DAILY = ROOT / "data" / "raw" / "cn_daily"
KEY_FILE = ROOT / "data" / "secrets" / "tickflow_api_key.txt"
TICKFLOW_BASE = os.environ.get("TICKFLOW_BASE", "https://api.tickflow.org")
XGT_REAL = os.environ.get(
    "XGT_REAL_URL", "https://api-ddc-wscn.xuangubao.com.cn/market/real"
)
UA = "Mozilla/5.0 (compatible; qinghong-quote-worker/1.2)"
XGT_HEADERS = {
    "User-Agent": UA,
    "Referer": "https://xuangutong.com.cn/dingpan",
    "Origin": "https://xuangutong.com.cn",
    "Accept": "application/json",
}
XGT_FIELDS = (
    "prod_name,last_px,px_change_rate,px_change,open_px,high_px,low_px,"
    "preclose_px,business_amount_in,turnover_ratio,update_time"
)
# 全 A 列表按代码倒序，前 N 全是科创板；硬编码保证茅台等进入热池
ENSURE_HOT = [
    "600519.SS",
    "000001.SZ",
    "000002.SZ",
    "600036.SS",
    "601318.SS",
    "000858.SZ",
    "002594.SZ",
    "300750.SZ",
    "601012.SS",
    "600900.SS",
    # 主流 ETF（不在 cn_ashare 纯股票列表；须硬进热池）
    "511880.SS",
    "510300.SS",
    "510500.SS",
    "159915.SZ",
]


def load_symbols(limit: int = 0, list_file: str = "", full: bool = False) -> list[str]:
    """full/hot=0 → 全 A（cn_ashare.txt）；否则优先 cn_hot + ENSURE。"""
    if list_file:
        fp = Path(list_file)
    elif full or limit == 0:
        fp = LIST_TXT
    else:
        fp = HOT_TXT if HOT_TXT.is_file() else LIST_TXT
    if not fp.is_file():
        fp = LIST_TXT
    raw = [ln.strip() for ln in fp.read_text(encoding="utf-8").splitlines() if ln.strip()]
    seen: set[str] = set()
    syms: list[str] = []
    # 全量时也把 ENSURE 置顶，便于验茅台
    head = ENSURE_HOT if (full or limit == 0 or fp == HOT_TXT) else ENSURE_HOT
    for s in head + raw:
        if s in seen:
            continue
        seen.add(s)
        syms.append(s)
    if limit and limit > 0:
        return syms[:limit]
    return syms


def to_sina(sym: str) -> str:
    code, mkt = sym.split(".")
    return ("sh" if mkt.upper() in {"SS", "SH"} else "sz") + code


def to_tickflow(sym: str) -> str:
    code, mkt = sym.split(".")
    m = mkt.upper()
    if m in {"SS", "SH"}:
        return f"{code}.SH"
    if m in {"SZ"}:
        return f"{code}.SZ"
    if m in {"BJ"}:
        return f"{code}.BJ"
    return f"{code}.{m}"


def from_tickflow(tf_sym: str) -> str:
    code, mkt = tf_sym.split(".")
    m = mkt.upper()
    if m == "SH":
        return f"{code}.SS"
    return f"{code}.{m}"


def redis_client(url: str):
    import redis  # type: ignore

    return redis.Redis.from_url(url, decode_responses=True)


def load_tickflow_key() -> str:
    env = (os.environ.get("TICKFLOW_API_KEY") or "").strip()
    if env:
        return env
    if KEY_FILE.is_file():
        try:
            return KEY_FILE.read_text(encoding="utf-8").strip()
        except OSError:
            # secrets 权限不足时不阻断选股通主路径
            return ""
    return ""


def fetch_xuangutong_batch(batch: list[str]) -> dict[str, dict]:
    """选股通 market/real 批量；SG 实测单批约 500 内可用，800 易 414。"""
    if not batch:
        return {}
    url = (
        f"{XGT_REAL}?prod_code={urllib.parse.quote(','.join(batch))}"
        f"&fields={urllib.parse.quote(XGT_FIELDS)}"
    )
    req = urllib.request.Request(url, headers=XGT_HEADERS)
    with urllib.request.urlopen(req, timeout=25) as resp:
        j = json.loads(resp.read().decode("utf-8", "ignore"))
    if j.get("code") not in (20000, 200, 0, None):
        raise RuntimeError(f"xgt_code={j.get('code')} msg={j.get('message')}")
    data = j.get("data") or {}
    fields = data.get("fields") or []
    snap = data.get("snapshot") or {}
    if not fields or not snap:
        return {}
    idx = {name: i for i, name in enumerate(fields)}

    def cell(row: list, key: str, default=None):
        i = idx.get(key)
        if i is None or i >= len(row):
            return default
        return row[i]

    out: dict[str, dict] = {}
    now = int(time.time())
    for sym, row in snap.items():
        if not isinstance(row, list):
            continue
        # 统一到 .SS（选股通偶发 .SH）
        code, _, mkt = sym.partition(".")
        m = (mkt or "SS").upper()
        if m == "SH":
            m = "SS"
        norm = f"{code}.{m}"
        ts_raw = cell(row, "update_time") or 0
        try:
            ts = int(ts_raw)
            if ts > 10_000_000_000:
                ts //= 1000
        except Exception:
            ts = now
        rate = cell(row, "px_change_rate")
        try:
            # 选股通：0.0757 ≈ 0.0757%（非小数涨跌幅）
            pct = float(rate) / 100.0 if rate is not None else None
        except Exception:
            pct = None
        out[norm] = {
            "symbol": norm,
            "name": cell(row, "prod_name"),
            "price": cell(row, "last_px"),
            "open": cell(row, "open_px"),
            "high": cell(row, "high_px"),
            "low": cell(row, "low_px"),
            "pre_close": cell(row, "preclose_px"),
            "volume": cell(row, "business_amount_in"),
            "pct_chg": pct,
            "change": cell(row, "px_change"),
            "turnover": cell(row, "turnover_ratio"),
            "src": "xuangutong.real",
            "ts": ts or now,
        }
    return out


def fetch_tickflow_batch(batch: list[str], api_key: str) -> dict[str, dict]:
    """TickFlow /v1/quotes；免费档约 5 标的/次。"""
    if not api_key or not batch:
        return {}
    tf_syms = [to_tickflow(s) for s in batch]
    url = f"{TICKFLOW_BASE}/v1/quotes?symbols={urllib.parse.quote(','.join(tf_syms))}"
    req = urllib.request.Request(
        url,
        headers={"User-Agent": UA, "X-API-Key": api_key, "Accept": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        j = json.loads(resp.read().decode("utf-8", "ignore"))
    rows = j.get("data") or []
    out: dict[str, dict] = {}
    for row in rows:
        tf = str(row.get("symbol") or "")
        if not tf:
            continue
        sym = from_tickflow(tf)
        ext = row.get("ext") or {}
        ts_ms = row.get("timestamp") or 0
        try:
            ts = int(ts_ms) // 1000 if int(ts_ms) > 10_000_000_000 else int(ts_ms)
        except Exception:
            ts = int(time.time())
        out[sym] = {
            "symbol": sym,
            "name": ext.get("name"),
            "price": row.get("last_price"),
            "open": row.get("open"),
            "high": row.get("high"),
            "low": row.get("low"),
            "pre_close": row.get("prev_close"),
            "volume": row.get("volume"),
            "amount": row.get("amount"),
            "pct_chg": ext.get("change_pct"),
            "change": ext.get("change_amount"),
            "src": "tickflow",
            "ts": ts or int(time.time()),
        }
    return out


def fetch_hq_sinajs(batch: list[str]) -> dict[str, dict]:
    """hq.sinajs.cn 批量；失败抛错。"""
    joined = ",".join(to_sina(s) for s in batch)
    url = f"https://hq.sinajs.cn/list={joined}"
    req = urllib.request.Request(
        url,
        headers={"User-Agent": UA, "Referer": "https://finance.sina.com.cn/"},
    )
    with urllib.request.urlopen(req, timeout=12) as resp:
        raw = resp.read().decode("gbk", "ignore")
    out: dict[str, dict] = {}
    for line in raw.splitlines():
        m = re.match(r'var hq_str_(\w+)="(.*)";', line.strip())
        if not m:
            continue
        sina, body = m.group(1), m.group(2)
        if not body:
            continue
        parts = body.split(",")
        if len(parts) < 32:
            continue
        if sina.startswith("sh"):
            sym = f"{sina[2:]}.SS"
        else:
            sym = f"{sina[2:]}.SZ"
        try:
            out[sym] = {
                "symbol": sym,
                "name": parts[0],
                "open": float(parts[1] or 0),
                "pre_close": float(parts[2] or 0),
                "price": float(parts[3] or 0),
                "high": float(parts[4] or 0),
                "low": float(parts[5] or 0),
                "volume": float(parts[8] or 0),
                "amount": float(parts[9] or 0),
                "date": parts[30] if len(parts) > 30 else "",
                "time": parts[31] if len(parts) > 31 else "",
                "src": "hq.sinajs.cn",
                "ts": int(time.time()),
            }
        except Exception:
            continue
    return out


def fetch_eastmoney_batch(batch: list[str]) -> dict[str, dict]:
    """东财 push2 秒级报价兜底。"""
    secs = []
    for s in batch:
        code, mkt = s.split(".")
        secid = f"{1 if mkt.upper() in {'SS', 'SH'} else 0}.{code}"
        secs.append(secid)
    hosts = [
        "https://push2.eastmoney.com/api/qt/ulist.np/get",
        "https://82.push2.eastmoney.com/api/qt/ulist.np/get",
    ]
    last_err = None
    j = None
    for base in hosts:
        url = (
            base
            + "?"
            + urllib.parse.urlencode(
                {
                    "fltt": "2",
                    "fields": "f12,f14,f2,f3,f4,f5,f6,f15,f16,f17,f18",
                    "secids": ",".join(secs),
                }
            )
        )
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://quote.eastmoney.com/"})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                j = json.loads(resp.read().decode("utf-8", "ignore"))
            break
        except Exception as e:
            last_err = e
            j = None
    if j is None:
        raise RuntimeError(str(last_err) if last_err else "em_empty")
    diff = (((j.get("data") or {}).get("diff")) or [])
    out: dict[str, dict] = {}
    for row in diff:
        code = str(row.get("f12") or "")
        cand = [s for s in batch if s.startswith(code + ".")]
        if not cand:
            continue
        sym = cand[0]
        out[sym] = {
            "symbol": sym,
            "name": row.get("f14"),
            "price": row.get("f2"),
            "pct_chg": row.get("f3"),
            "change": row.get("f4"),
            "volume": row.get("f5"),
            "amount": row.get("f6"),
            "high": row.get("f15"),
            "low": row.get("f16"),
            "open": row.get("f17"),
            "pre_close": row.get("f18"),
            "src": "eastmoney.push2",
            "ts": int(time.time()),
        }
    return out


def fetch_sina_kline_quote(batch: list[str]) -> dict[str, dict]:
    """用新浪 K 线末日作收盘后 Delayed 报价。"""
    out: dict[str, dict] = {}
    for sym in batch:
        code, mkt = sym.split(".")
        sina = ("sh" if mkt.upper() in {"SS", "SH"} else "sz") + code
        url = (
            "https://quotes.sina.cn/cn/api/openapi.php/CN_MarketDataService.getKLineData"
            f"?symbol={urllib.parse.quote(sina)}&scale=240&ma=no&datalen=3"
        )
        req = urllib.request.Request(
            url, headers={"User-Agent": UA, "Referer": "https://finance.sina.com.cn/"}
        )
        try:
            with urllib.request.urlopen(req, timeout=12) as resp:
                j = json.loads(resp.read().decode("utf-8", "ignore"))
            arr = (((j.get("result") or {}).get("data")) or [])
            if not arr:
                continue
            last = arr[-1]
            out[sym] = {
                "symbol": sym,
                "price": float(last.get("close") or 0),
                "open": float(last.get("open") or 0),
                "high": float(last.get("high") or 0),
                "low": float(last.get("low") or 0),
                "volume": float(last.get("volume") or 0),
                "date": str(last.get("day") or "")[:10],
                "src": "sina.kline",
                "ts": int(time.time()),
            }
        except Exception:
            continue
        time.sleep(0.03)
    return out


def seed_from_cold(batch: list[str]) -> dict[str, dict]:
    """冷库末日灌热，保证 Redis 有 key（盘后/源全挂时）。"""
    out: dict[str, dict] = {}
    for sym in batch:
        fp = CN_DAILY / f"{sym}.json"
        if not fp.is_file():
            continue
        try:
            j = json.loads(fp.read_text(encoding="utf-8"))
            rows = j.get("rows") or j.get("bars") or []
            if not rows:
                continue
            last = rows[-1]
            out[sym] = {
                "symbol": sym,
                "price": last.get("close") or last.get("price"),
                "open": last.get("open"),
                "high": last.get("high"),
                "low": last.get("low"),
                "volume": last.get("volume") or last.get("vol"),
                "date": str(last.get("date") or last.get("day") or "")[:10],
                "src": "cold.seed",
                "ts": int(time.time()),
            }
        except Exception:
            continue
    return out


def write_redis(r, quotes: dict[str, dict], ttl: int) -> int:
    pipe = r.pipeline()
    n = 0
    for sym, q in quotes.items():
        key = f"qh:quote:cn:{sym}"
        pipe.set(key, json.dumps(q, ensure_ascii=False, separators=(",", ":")), ex=ttl)
        n += 1
    pipe.execute()
    return n


def fetch_batch(batch: list[str], api_key: str, prefer: str) -> tuple[dict[str, dict], str]:
    """按 prefer 顺序取一批报价。"""
    order = {
        "xuangutong": ["xuangutong", "tickflow", "sina_kline", "em", "sina", "cold"],
        "tickflow": ["tickflow", "xuangutong", "sina_kline", "em", "sina", "cold"],
        "sina": ["sina", "em", "xuangutong", "tickflow", "sina_kline", "cold"],
        "auto": ["xuangutong", "tickflow", "sina", "em", "sina_kline", "cold"],
    }.get(prefer, ["xuangutong", "tickflow", "sina_kline", "em", "sina", "cold"])

    last_err = ""
    for src in order:
        try:
            if src == "xuangutong":
                q = fetch_xuangutong_batch(batch)
                if q:
                    return q, "xuangutong.real"
            elif src == "tickflow":
                q = fetch_tickflow_batch(batch, api_key)
                if q:
                    return q, "tickflow"
            elif src == "sina":
                q = fetch_hq_sinajs(batch)
                if q:
                    return q, "hq.sinajs.cn"
            elif src == "em":
                q = fetch_eastmoney_batch(batch)
                if q:
                    return q, "eastmoney.push2"
            elif src == "sina_kline":
                q = fetch_sina_kline_quote(batch)
                if q:
                    return q, "sina.kline"
            elif src == "cold":
                q = seed_from_cold(batch)
                if q:
                    return q, "cold.seed"
        except Exception as e:
            last_err = f"{src}:{e}"
            print(f"src_fail {last_err}", flush=True)
            continue
    if last_err:
        print(f"batch_empty {last_err}", flush=True)
    return {}, "none"


def run_round(r, syms: list[str], args, api_key: str) -> tuple[int, str, float]:
    """全市场一轮：支持多批并行。"""
    t0 = time.time()
    batches = [syms[i : i + args.batch] for i in range(0, len(syms), args.batch)]
    wrote = 0
    src_used = "none"
    workers = max(1, int(args.workers))

    def _one(batch: list[str]) -> tuple[int, str]:
        quotes, src = fetch_batch(batch, api_key, args.prefer)
        if not quotes:
            return 0, src
        return write_redis(r, quotes, args.ttl), src

    if workers <= 1 or len(batches) <= 1:
        for batch in batches:
            n, src_used = _one(batch)
            wrote += n
            if src_used == "tickflow":
                time.sleep(6.5)
            elif src_used == "xuangutong.real":
                time.sleep(0.12)
            else:
                time.sleep(0.08)
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futs = [pool.submit(_one, b) for b in batches]
            for fut in as_completed(futs):
                try:
                    n, src = fut.result()
                    wrote += n
                    if n:
                        src_used = src
                except Exception as e:
                    print(f"parallel_fail {e}", flush=True)

    try:
        r.set(
            "qh:quote:cn:_meta",
            json.dumps(
                {"n": wrote, "ts": int(time.time()), "src": src_used, "universe": len(syms)},
                ensure_ascii=False,
            ),
            ex=args.ttl,
        )
    except Exception:
        pass
    return wrote, src_used, time.time() - t0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--hot", type=int, default=0, help="热门池大小；0=全 A")
    ap.add_argument("--full", action="store_true", help="强制全 A（等同 --hot 0）")
    ap.add_argument("--batch", type=int, default=200, help="每批标的数（选股通建议 150~300）")
    ap.add_argument("--workers", type=int, default=6, help="并行批次数")
    ap.add_argument("--interval", type=float, default=20.0)
    ap.add_argument("--ttl", type=int, default=180)
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--ignore-gate", action="store_true", help="忽略交易日闸门（盘后灌 Redis）")
    ap.add_argument(
        "--prefer",
        default="xuangutong",
        choices=["auto", "xuangutong", "tickflow", "sina"],
    )
    ap.add_argument("--list", default="", help="标的列表；全 A 默认 cn_ashare.txt")
    ap.add_argument("--redis", default=os.environ.get("REDIS_URL", "redis://127.0.0.1:6379/0"))
    args = ap.parse_args()
    if args.full:
        args.hot = 0

    syms = load_symbols(args.hot, args.list, full=bool(args.full or args.hot == 0))
    r = redis_client(args.redis)
    r.ping()
    api_key = load_tickflow_key()
    print(
        f"worker start n={len(syms)} batch={args.batch} workers={args.workers} "
        f"prefer={args.prefer} tickflow_key={'yes' if api_key else 'no'} redis={args.redis}",
        flush=True,
    )

    while True:
        ok_gate, reason = should_pull("cn")
        if not ok_gate and not args.ignore_gate:
            print(f"skip cn: {reason}", flush=True)
            if args.once:
                break
            time.sleep(max(300.0, args.interval * 10))
            continue
        if not ok_gate and args.ignore_gate:
            print(f"gate note: {reason} (ignore-gate on)", flush=True)
        wrote, src_used, cost = run_round(r, syms, args, api_key)
        print(f"round wrote={wrote} cost={cost:.1f}s src={src_used}", flush=True)
        if args.once:
            break
        time.sleep(max(1.0, args.interval))


if __name__ == "__main__":
    main()
