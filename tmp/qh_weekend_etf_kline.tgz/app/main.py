#!/usr/bin/env python3
"""晴红行情 API — 只读本地冷库 / Redis，禁止透传爬源。"""
from __future__ import annotations

import json
import os
import time
from contextvars import ContextVar
from pathlib import Path
from typing import Any, Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import JSONResponse

ROOT = Path(os.environ.get("QINGHONG_ROOT", Path(__file__).resolve().parents[1]))
DATA = ROOT / "data" / "raw"
KEYS_FILE = ROOT / "data" / "api_keys.json"
SECRETS_DIR = ROOT / "data" / "secrets"
SYNC_TOKEN_FILE = SECRETS_DIR / "market_keys_sync_token.txt"
CN_DIR = DATA / "cn_daily"
US_DIR = DATA / "us_daily"
FU_DIR = DATA / "futures_daily"
CNF_DIR = DATA / "cn_futures_daily"
LIMIT_UP_DIR = DATA / "cn_limit_up"
SENTIMENT_DIR = DATA / "cn_sentiment"
SECTOR_DIR = DATA / "cn_sectors"
MONEYFLOW_DIR = DATA / "cn_moneyflow"

# 当前请求鉴权上下文（供 ok() 判断是否跳过品牌脱敏）
_AUTH_CTX: ContextVar[Optional[dict]] = ContextVar("qh_auth", default=None)
_KEYS_CACHE: dict[str, Any] = {"mtime": None, "data": {}}

app = FastAPI(title="晴红 · 行情数据 API", version="0.1.2")

from app.rate_limit import daily_used, enforce_rate_limits  # noqa: E402
from app.brand import brand_src, scrub_message, scrub_public  # noqa: E402
from lib.trading_session import cn_session_ymd  # noqa: E402

ALLOWED_CUSTOMER_PLANS = frozenset({"standard", "pro", "trial_week", "trial_day"})
PROTECTED_KEY_PREFIXES = ("sk-qh-admin-",)


def _default_keys() -> dict:
    return {
        "keys": {
            "sk-market-demo0001": {
                "plan": "standard",
                "markets": ["cn", "us", "futures", "cn_futures"],
                "daily_quota": 30000,
                "qps": 5,
                "expire": "2099-12-31",
            }
        }
    }


def _load_keys() -> dict:
    """按 mtime 热读 api_keys.json，sync 后无需重启。"""
    if not KEYS_FILE.exists():
        return _default_keys()
    try:
        mtime = KEYS_FILE.stat().st_mtime
    except OSError:
        return _KEYS_CACHE.get("data") or _default_keys()
    if _KEYS_CACHE.get("mtime") == mtime and _KEYS_CACHE.get("data"):
        return _KEYS_CACHE["data"]
    try:
        data = json.loads(KEYS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = _default_keys()
        if "keys" not in data or not isinstance(data["keys"], dict):
            data = _default_keys()
        _KEYS_CACHE["mtime"] = mtime
        _KEYS_CACHE["data"] = data
        return data
    except Exception:
        return _KEYS_CACHE.get("data") or _default_keys()


def _sync_token() -> str:
    env = (os.environ.get("MARKET_KEYS_SYNC_TOKEN") or "").strip()
    if env:
        return env
    try:
        if SYNC_TOKEN_FILE.exists():
            return SYNC_TOKEN_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return ""


def _require_sync_token(x_admin_sync_token: Optional[str] = Header(default=None, alias="X-Admin-Sync-Token")) -> None:
    expected = _sync_token()
    if not expected:
        raise HTTPException(503, detail={"code": 503, "message": "sync token not configured"})
    got = (x_admin_sync_token or "").strip()
    if not got or got != expected:
        raise HTTPException(401, detail={"code": 401, "message": "invalid sync token"})


def _is_protected_key(key: str, meta: Optional[dict] = None) -> bool:
    if any(key.startswith(p) for p in PROTECTED_KEY_PREFIXES):
        return True
    if not meta:
        return False
    role = str(meta.get("role") or "")
    plan = str(meta.get("plan") or "")
    features = meta.get("features") or []
    if isinstance(features, str):
        features = [features]
    return role == "superadmin" or plan == "admin" or "*" in features


def _backup_keys_file() -> Optional[str]:
    if not KEYS_FILE.exists():
        return None
    stamp = time.strftime("%Y%m%d%H%M%S")
    bak_dir = SECRETS_DIR / "keys_bak"
    bak_dir.mkdir(parents=True, exist_ok=True)
    bak = bak_dir / f"api_keys.json.bak.{stamp}"
    bak.write_bytes(KEYS_FILE.read_bytes())
    return str(bak.relative_to(ROOT))


def _atomic_write_keys(data: dict) -> None:
    KEYS_FILE.parent.mkdir(parents=True, exist_ok=True)
    SECRETS_DIR.mkdir(parents=True, exist_ok=True)
    tmp = SECRETS_DIR / "api_keys.json.tmp"
    raw = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    tmp.write_text(raw, encoding="utf-8")
    # 先写到 secrets 再 replace，避免 data/ 目录不可写时整段失败
    tmp.replace(KEYS_FILE)
    try:
        mtime = KEYS_FILE.stat().st_mtime
    except OSError:
        mtime = time.time()
    _KEYS_CACHE["mtime"] = mtime
    _KEYS_CACHE["data"] = data


def require_key(
    request: Request,
    x_api_key: Optional[str] = Header(default=None, alias="X-API-Key"),
) -> dict:
    if not x_api_key:
        raise HTTPException(401, detail={"code": 401, "message": "missing X-API-Key"})
    keys = _load_keys().get("keys") or {}
    meta = keys.get(x_api_key)
    if not meta:
        raise HTTPException(401, detail={"code": 401, "message": "invalid api key"})
    expire = str(meta.get("expire") or "2099-12-31")
    if expire < time.strftime("%Y-%m-%d"):
        raise HTTPException(403, detail={"code": 403, "message": "key expired"})
    role = str(meta.get("role") or "")
    plan = str(meta.get("plan") or "")
    features = meta.get("features") or []
    if isinstance(features, str):
        features = [features]
    unlimited = (
        role == "superadmin"
        or plan == "admin"
        or int(meta.get("daily_quota") or 0) < 0
        or "*" in features
    )
    # 超管 / features=*：测试用全开
    full_access = unlimited or role == "superadmin" or plan in {"admin", "pro"} or "*" in features
    markets = meta.get("markets") or []
    if unlimited or full_access or "*" in markets:
        markets = ["cn", "us", "futures", "cn_futures", "*"]
    try:
        batch_limit = int(meta.get("batch_limit") or (200 if full_access else 20))
    except Exception:
        batch_limit = 200 if full_access else 20
    if full_access:
        batch_limit = max(batch_limit, 200)
    auth = {
        "key": x_api_key,
        **meta,
        "markets": markets,
        "features": ["*"] if full_access else list(features),
        "full_access": bool(full_access),
        "batch_limit": batch_limit,
        "unlimited": unlimited,
        "daily_quota": -1 if unlimited else meta.get("daily_quota"),
        "qps": -1 if unlimited else meta.get("qps"),
        # 仅超管/admin 可见真实上游 src；商用 unlimited 不得连带开 reveal
        "reveal_src": bool(role == "superadmin" or plan == "admin"),
    }
    _AUTH_CTX.set(auth)
    path = request.url.path
    # /v1/me 不计入日配额、不因配额满而拒绝，便于客户自查剩余
    if path == "/v1/me":
        enforce_rate_limits(auth, count=False, check_quota=False, check_qps=True)
    else:
        enforce_rate_limits(auth, count=True, check_quota=True, check_qps=True)
    return auth


def ok(data: Any, *, auth: Optional[dict] = None, **extra) -> dict:
    """统一出口：客户 Key 品牌化；超管传 auth= 保留真实 src。"""
    a = auth if auth is not None else (_AUTH_CTX.get() or {})
    reveal = bool(a.get("reveal_src"))
    if reveal:
        body: dict[str, Any] = {"code": 0, "message": "ok", "data": data}
        body.update(extra)
        return body
    body = {"code": 0, "message": "ok", "data": scrub_public(data)}
    for k, v in extra.items():
        if k == "src":
            body[k] = brand_src(v if isinstance(v, str) else None)
        elif isinstance(v, (dict, list)):
            body[k] = scrub_public(v)
        else:
            body[k] = v
    return body


def _batch_cap(auth: dict, n_default: int = 20) -> int:
    try:
        return max(1, int(auth.get("batch_limit") or n_default))
    except Exception:
        return n_default


def _require_market(auth: dict, market: str) -> None:
    """非全开 Key 校验市场权限；超管跳过。"""
    if auth.get("full_access") or auth.get("unlimited"):
        return
    markets = auth.get("markets") or []
    if "*" in markets or market in markets:
        return
    raise HTTPException(403, detail={"code": 403, "message": f"market {market} not in key scope"})


def _norm_cn(symbol: str) -> str:
    s = symbol.strip().upper().replace("SH", "SS")
    if "." in s:
        return s
    if s.startswith(("5", "6", "9")):
        return f"{s}.SS"
    return f"{s}.SZ"


def _cn_asof_day(date: Optional[str]) -> str:
    """未显式传 date 时：交易日=今天；休市=上一交易日。"""
    if date and str(date).strip():
        return str(date).strip()[:10]
    return cn_session_ymd()


def _hot_day(body: Optional[dict]) -> str:
    if not body:
        return ""
    return str(body.get("date") or body.get("asof_date") or "")[:10]


def _read_json(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _cnf_path(symbol: str) -> Path:
    """国内期货文件名大小写不敏感（冷库多为 rbm.json，列表偶有 IFM）。"""
    s = symbol.strip()
    for cand in (s, s.lower(), s.upper(), s[:1].lower() + s[1:] if s else s):
        p = CNF_DIR / f"{cand}.json"
        if p.exists():
            return p
    return CNF_DIR / f"{s}.json"


def _redis_get(key: str) -> Optional[dict]:
    try:
        import redis  # type: ignore

        url = os.environ.get("REDIS_URL", "redis://127.0.0.1:6379/0")
        r = redis.Redis.from_url(url, decode_responses=True, socket_connect_timeout=0.4)
        raw = r.get(key)
        if not raw:
            return None
        return json.loads(raw)
    except Exception:
        return None


@app.get("/")
def root():
    return {
        "brand": "晴红 · 行情数据 API",
        "version": "0.1.0",
        "docs": "飞书文档",
        "health": "/health",
    }


@app.get("/health")
def health():
    return {"ok": True, "service": "qinghong-market-api", "port": 18080, "ts": int(time.time())}


@app.get("/v1/me")
def me(auth: dict = Depends(require_key)):
    """当前 Key 元信息（不含密钥明文以外的回显）。"""
    used = None if auth.get("unlimited") else daily_used(str(auth.get("key") or ""))
    quota = auth.get("daily_quota")
    remaining = None
    if used is not None and quota is not None and int(quota) >= 0:
        remaining = max(0, int(quota) - int(used))
    me_data: dict[str, Any] = {
        "plan": auth.get("plan"),
        "role": auth.get("role"),
        "markets": auth.get("markets"),
        "features": auth.get("features"),
        "full_access": bool(auth.get("full_access")),
        "batch_limit": auth.get("batch_limit"),
        "daily_quota": auth.get("daily_quota"),
        "daily_used": used,
        "daily_remaining": remaining,
        "qps": auth.get("qps"),
        "unlimited": bool(auth.get("unlimited")),
        "expire": auth.get("expire"),
        "note": auth.get("note"),
        "rate_limit": "bypassed" if auth.get("unlimited") else "enforced",
        "code_rev": "2026-08-01-weekend-etf-kline-v1",
    }
    # reveal_src 仅对超管回显，避免客户侧感知存在「真源开关」
    if auth.get("reveal_src"):
        me_data["reveal_src"] = True
    return ok(me_data, auth=auth)


def _customer_key_ok(key: str) -> bool:
    if key.startswith("sk-qh-admin-"):
        return False
    return key.startswith("sk-qh-") or key.startswith("sk-market-")


@app.post("/v1/admin/keys/upsert")
def admin_keys_upsert(body: dict[str, Any], _: None = Depends(_require_sync_token)):
    """国内管理台同步：写入/更新客户 Key（禁止超管键）。不计入客户配额。"""
    key = str(body.get("key") or "").strip()
    if not _customer_key_ok(key):
        raise HTTPException(400, detail={"code": 400, "message": "key must start with sk-qh- or sk-market-"})
    if _is_protected_key(key):
        raise HTTPException(403, detail={"code": 403, "message": "admin key protected"})

    plan = str(body.get("plan") or "standard").strip()
    if plan not in ALLOWED_CUSTOMER_PLANS:
        raise HTTPException(400, detail={"code": 400, "message": f"plan must be one of {sorted(ALLOWED_CUSTOMER_PLANS)}"})

    markets = body.get("markets") or ["cn", "cn_futures"]
    if not isinstance(markets, list) or not markets:
        raise HTTPException(400, detail={"code": 400, "message": "markets required"})
    if "*" in markets:
        raise HTTPException(403, detail={"code": 403, "message": "wildcard markets not allowed"})

    try:
        daily_quota = int(body.get("daily_quota") if body.get("daily_quota") is not None else (150000 if plan == "pro" else 30000))
        qps = int(body.get("qps") if body.get("qps") is not None else (15 if plan == "pro" else 5))
        batch_limit = int(body.get("batch_limit") if body.get("batch_limit") is not None else 20)
    except Exception:
        raise HTTPException(400, detail={"code": 400, "message": "invalid quota/qps/batch_limit"})
    if daily_quota < 0 or qps < 0:
        raise HTTPException(403, detail={"code": 403, "message": "negative quota/qps not allowed"})

    expire = str(body.get("expire") or "").strip()
    if not expire or len(expire) < 10:
        raise HTTPException(400, detail={"code": 400, "message": "expire YYYY-MM-DD required"})

    note = str(body.get("note") or "")[:120]
    meta: dict[str, Any] = {
        "plan": plan,
        "markets": [str(m) for m in markets],
        "daily_quota": daily_quota,
        "qps": qps,
        "batch_limit": max(1, min(batch_limit, 50)),
        "expire": expire[:10],
        "note": note,
    }
    if plan == "pro":
        meta["features"] = ["pro"]

    data = _load_keys()
    keys = dict(data.get("keys") or {})
    existing = keys.get(key)
    if existing and _is_protected_key(key, existing if isinstance(existing, dict) else None):
        raise HTTPException(403, detail={"code": 403, "message": "admin key protected"})

    bak = _backup_keys_file()
    keys[key] = meta
    data["keys"] = keys
    _atomic_write_keys(data)
    return {"ok": True, "key": key, "meta": meta, "backup": bak}


@app.post("/v1/admin/keys/revoke")
def admin_keys_revoke(body: dict[str, Any], _: None = Depends(_require_sync_token)):
    """停用：默认将 expire 置为昨天；delete=true 时删除键（仍禁止超管）。"""
    key = str(body.get("key") or "").strip()
    if not _customer_key_ok(key):
        raise HTTPException(400, detail={"code": 400, "message": "key must start with sk-qh- or sk-market-"})
    data = _load_keys()
    keys = dict(data.get("keys") or {})
    existing = keys.get(key)
    if not existing:
        return {"ok": True, "key": key, "action": "missing"}
    if _is_protected_key(key, existing if isinstance(existing, dict) else None):
        raise HTTPException(403, detail={"code": 403, "message": "admin key protected"})

    bak = _backup_keys_file()
    delete = bool(body.get("delete"))
    if delete:
        keys.pop(key, None)
        action = "deleted"
        meta = None
    else:
        yday = time.strftime("%Y-%m-%d", time.localtime(time.time() - 86400))
        meta = dict(existing)
        meta["expire"] = yday
        keys[key] = meta
        action = "expired"
    data["keys"] = keys
    _atomic_write_keys(data)
    return {"ok": True, "key": key, "action": action, "meta": meta, "backup": bak}


@app.get("/v1/admin/keys/list")
def admin_keys_list(_: None = Depends(_require_sync_token)):
    """列出客户 Key（脱敏超管明文）。"""
    data = _load_keys()
    out = []
    for k, meta in (data.get("keys") or {}).items():
        if not isinstance(meta, dict):
            continue
        if _is_protected_key(k, meta):
            out.append({"key": k[:12] + "…", "plan": meta.get("plan"), "protected": True})
            continue
        out.append(
            {
                "key": k,
                "plan": meta.get("plan"),
                "markets": meta.get("markets"),
                "expire": meta.get("expire"),
                "note": meta.get("note"),
                "daily_quota": meta.get("daily_quota"),
                "qps": meta.get("qps"),
            }
        )
    return {"ok": True, "count": len(out), "keys": out}


@app.get("/v1/markets/status")
def markets_status(auth: dict = Depends(require_key)):
    def last_cn():
        p = CN_DIR / "600519.SS.json"
        d = _read_json(p)
        bars = (d or {}).get("bars") or []
        return bars[-1].get("date") if bars else None

    def last_us():
        d = _read_json(US_DIR / "AAPL.json")
        rows = (d or {}).get("rows") or []
        if not rows:
            return None
        return time.strftime("%Y-%m-%d", time.gmtime(rows[-1]["t"]))

    return ok(
        {
            "cn": {"sample": "600519.SS", "last_trade_date": last_cn()},
            "us": {"sample": "AAPL", "last_trade_date": last_us()},
            "server_time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        },
        auth=auth,
    )


@app.get("/v1/cn/quote")
def cn_quote(symbols: str = Query(..., description="逗号分隔，最多20"), auth: dict = Depends(require_key)):
    _require_market(auth, "cn")
    cap = _batch_cap(auth)
    syms = [x.strip() for x in symbols.split(",") if x.strip()][:cap]
    out = []
    for raw in syms:
        sym = _norm_cn(raw)
        q = _redis_get(f"qh:quote:cn:{sym}")
        if q:
            out.append(q)
            continue
        d = _read_json(CN_DIR / f"{sym}.json")
        bars = (d or {}).get("bars") or []
        if not bars:
            out.append({"symbol": sym, "error": "not_found"})
            continue
        last = bars[-1]
        out.append(
            {
                "symbol": sym,
                "price": last.get("close"),
                "open": last.get("open"),
                "high": last.get("high"),
                "low": last.get("low"),
                "volume": last.get("volume"),
                "date": last.get("date"),
                "src": "cold.last_bar",
                "ts": int(time.time()),
            }
        )
    return ok(out, auth=auth, count=len(out))


@app.get("/v1/cn/kline")
def cn_kline(
    symbol: str,
    period: str = "1d",
    start: Optional[str] = None,
    end: Optional[str] = None,
    limit: Optional[int] = None,
    auth: dict = Depends(require_key),
):
    _require_market(auth, "cn")
    if period not in {"1d", "5m", "1m", "15m", "30m", "60m"}:
        raise HTTPException(400, detail={"code": 400, "message": f"unsupported period {period}"})
    if period != "1d" and not auth.get("full_access"):
        raise HTTPException(403, detail={"code": 403, "message": "minute kline requires Pro"})
    sym = _norm_cn(symbol)
    d = _read_json(CN_DIR / f"{sym}.json")
    if not d:
        raise HTTPException(404, detail={"code": 404, "message": f"no data for {sym}"})
    if period != "1d":
        # 超管可过闸；分钟库尚未落地时明确 404（非权限问题）
        raise HTTPException(
            404,
            detail={"code": 404, "message": f"no {period} kline data for {sym} yet"},
        )
    bars = list(d.get("bars") or [])
    if start:
        bars = [b for b in bars if str(b.get("date")) >= start]
    if end:
        bars = [b for b in bars if str(b.get("date")) <= end]
    if limit and limit > 0:
        bars = bars[-limit:]
    return ok({"symbol": sym, "period": period, "bars": bars}, auth=auth, count=len(bars))


@app.get("/v1/us/quote")
def us_quote(symbols: str = Query(...), auth: dict = Depends(require_key)):
    _require_market(auth, "us")
    cap = _batch_cap(auth)
    syms = [x.strip().upper() for x in symbols.split(",") if x.strip()][:cap]
    out = []
    for sym in syms:
        q = _redis_get(f"qh:quote:us:{sym}")
        if q:
            out.append(q)
            continue
        d = _read_json(US_DIR / f"{sym}.json")
        rows = (d or {}).get("rows") or []
        if not rows:
            out.append({"symbol": sym, "error": "not_found"})
            continue
        last = rows[-1]
        out.append(
            {
                "symbol": sym,
                "price": last.get("c"),
                "open": last.get("o"),
                "high": last.get("h"),
                "low": last.get("l"),
                "volume": last.get("v"),
                "date": time.strftime("%Y-%m-%d", time.gmtime(last["t"])),
                "src": "cold.last_bar",
                "delay_hint": "delayed",
                "ts": int(time.time()),
            }
        )
    return ok(out, auth=auth, count=len(out))


@app.get("/v1/us/kline")
def us_kline(
    symbol: str,
    period: str = "1d",
    start: Optional[str] = None,
    end: Optional[str] = None,
    limit: Optional[int] = None,
    auth: dict = Depends(require_key),
):
    _require_market(auth, "us")
    if period not in {"1d"} and not auth.get("full_access"):
        raise HTTPException(403, detail={"code": 403, "message": "only 1d for now"})
    if period != "1d":
        raise HTTPException(404, detail={"code": 404, "message": f"no {period} kline data yet"})
    sym = symbol.strip().upper()
    d = _read_json(US_DIR / f"{sym}.json")
    if not d:
        raise HTTPException(404, detail={"code": 404, "message": f"no data for {sym}"})
    rows = list(d.get("rows") or [])
    bars = []
    for r in rows:
        day = time.strftime("%Y-%m-%d", time.gmtime(r["t"]))
        if start and day < start:
            continue
        if end and day > end:
            continue
        bars.append(
            {
                "date": day,
                "open": r.get("o"),
                "high": r.get("h"),
                "low": r.get("l"),
                "close": r.get("c"),
                "volume": r.get("v"),
                "adjclose": r.get("a"),
            }
        )
    if limit and limit > 0:
        bars = bars[-limit:]
    return ok({"symbol": sym, "period": period, "bars": bars}, auth=auth, count=len(bars))


@app.get("/v1/futures/quote")
def futures_quote(symbols: str = Query(...), auth: dict = Depends(require_key)):
    _require_market(auth, "futures")
    cap = _batch_cap(auth)
    syms = [x.strip().upper() for x in symbols.split(",") if x.strip()][:cap]
    out = []
    for sym in syms:
        ysym = sym if "=" in sym or sym.endswith("=F") else f"{sym}=F"
        q = _redis_get(f"qh:quote:futures:{ysym}") or _redis_get(f"qh:quote:futures:{sym}")
        if q:
            out.append(q)
            continue
        # CL -> CL_F.json
        fname = sym if sym.endswith("_F") else (sym.replace("=", "_") + ("_F" if not sym.endswith("F") else ""))
        if not fname.endswith("_F"):
            fname = f"{sym}_F"
        d = _read_json(FU_DIR / f"{fname}.json")
        rows = (d or {}).get("rows") or []
        if not rows:
            d = _read_json(FU_DIR / f"{sym}_F.json")
            rows = (d or {}).get("rows") or []
        if not rows:
            out.append({"symbol": sym, "error": "not_found"})
            continue
        last = rows[-1]
        out.append(
            {
                "symbol": sym,
                "price": last.get("c"),
                "open": last.get("o"),
                "high": last.get("h"),
                "low": last.get("l"),
                "volume": last.get("v"),
                "date": time.strftime("%Y-%m-%d", time.gmtime(last["t"])),
                "src": "cold.last_bar",
                "delay_hint": "delayed",
            }
        )
    return ok(out, auth=auth, count=len(out))


@app.get("/v1/futures/kline")
def futures_kline(
    symbol: str,
    period: str = "1d",
    limit: Optional[int] = None,
    auth: dict = Depends(require_key),
):
    _require_market(auth, "futures")
    if period != "1d" and not auth.get("full_access"):
        raise HTTPException(403, detail={"code": 403, "message": "only 1d for now"})
    if period != "1d":
        raise HTTPException(404, detail={"code": 404, "message": f"no {period} kline data yet"})
    sym = symbol.strip().upper().replace("=F", "").replace("_F", "")
    d = _read_json(FU_DIR / f"{sym}_F.json")
    if not d:
        raise HTTPException(404, detail={"code": 404, "message": f"no data for {sym}"})
    rows = list(d.get("rows") or [])
    bars = [
        {
            "date": time.strftime("%Y-%m-%d", time.gmtime(r["t"])),
            "open": r.get("o"),
            "high": r.get("h"),
            "low": r.get("l"),
            "close": r.get("c"),
            "volume": r.get("v"),
        }
        for r in rows
    ]
    if limit and limit > 0:
        bars = bars[-limit:]
    return ok({"symbol": sym, "period": period, "bars": bars}, auth=auth, count=len(bars))


@app.get("/v1/cn-futures/list")
def cn_futures_list(kind: Optional[str] = None, auth: dict = Depends(require_key)):
    _require_market(auth, "cn_futures")
    lst = ROOT / "data" / "lists" / "cn_futures.json"
    raw = _read_json(lst) or {"symbols": []}
    syms = raw.get("symbols") or []
    if kind:
        syms = [s for s in syms if s.get("kind") == kind]
    # 超管全量；客户默认最多 500
    cap = None if auth.get("full_access") else 500
    shown = syms if cap is None else syms[:cap]
    return ok({"total": len(syms), "symbols": shown, "returned": len(shown)}, auth=auth, count=len(shown))


@app.get("/v1/cn-futures/quote")
def cn_futures_quote(symbols: str = Query(...), auth: dict = Depends(require_key)):
    _require_market(auth, "cn_futures")
    cap = _batch_cap(auth)
    syms = [x.strip() for x in symbols.split(",") if x.strip()][:cap]
    out = []
    for sym in syms:
        q = (
            _redis_get(f"qh:quote:cnf:{sym}")
            or _redis_get(f"qh:quote:cnf:{sym.lower()}")
            or _redis_get(f"qh:quote:cnf:{sym.upper()}")
        )
        if q:
            out.append(q)
            continue
        d = _read_json(_cnf_path(sym))
        bars = (d or {}).get("bars") or []
        if not bars:
            out.append({"symbol": sym, "error": "not_found"})
            continue
        last = bars[-1]
        out.append(
            {
                "symbol": (d or {}).get("symbol") or sym,
                "name": (d or {}).get("name"),
                "price": last.get("close"),
                "open": last.get("open"),
                "high": last.get("high"),
                "low": last.get("low"),
                "volume": last.get("volume"),
                "date": last.get("date"),
                "src": "cold.last_bar",
                "ts": int(time.time()),
            }
        )
    return ok(out, auth=auth, count=len(out))


@app.get("/v1/cn-futures/kline")
def cn_futures_kline(
    symbol: str,
    period: str = "1d",
    start: Optional[str] = None,
    end: Optional[str] = None,
    limit: Optional[int] = None,
    auth: dict = Depends(require_key),
):
    _require_market(auth, "cn_futures")
    d = _read_json(_cnf_path(symbol))
    if not d:
        raise HTTPException(404, detail={"code": 404, "message": f"no data for {symbol}"})
    bars = list(d.get("bars") or [])
    if start:
        bars = [b for b in bars if str(b.get("date")) >= start]
    if end:
        bars = [b for b in bars if str(b.get("date")) <= end]
    if limit and limit > 0:
        bars = bars[-limit:]
    return ok(
        {"symbol": d.get("symbol") or symbol, "name": d.get("name"), "period": period, "bars": bars},
        auth=auth,
        count=len(bars),
    )


@app.get("/v1/cn/limit-up")
def cn_limit_up(
    date: Optional[str] = None,
    pool: str = Query("limit_up", description="limit_up|yesterday_limit_up|limit_up_broken|limit_down|super_stock"),
    auth: dict = Depends(require_key),
):
    """涨停池/解读：优先 Redis（会话日），其次日冷库。"""
    _require_market(auth, "cn")
    day = _cn_asof_day(date)
    pool_name = (pool or "limit_up").strip()
    if pool_name == "limit_up":
        hot = _redis_get("qh:cn:limit_up:today")
    else:
        hot = _redis_get(f"qh:cn:pool:{pool_name}")
    # 热数据 date/asof 对上会话日才用；休市残留若误标日历日，仍回落到会话日冷库
    if hot and (_hot_day(hot) == day or (not date and _hot_day(hot) in {day, time.strftime("%Y-%m-%d")})):
        if _hot_day(hot) != day:
            hot = {**hot, "date": day, "asof_date": day}
        return ok(hot, auth=auth, src=hot.get("src") or "redis", count=hot.get("count") or len(hot.get("items") or []))

    cold = _read_json(LIMIT_UP_DIR / f"{day}.json")
    if not cold:
        raise HTTPException(
            404,
            detail={"code": 404, "message": f"no limit-up data for {day}"},
        )
    block = ((cold.get("pools") or {}).get(pool_name)) or {}
    items = block.get("items") or []
    return ok(
        {
            "date": day,
            "pool": pool_name,
            "count": block.get("count") if block.get("count") is not None else len(items),
            "items": items,
            "src": cold.get("src") or "cold",
            "ts": cold.get("ts"),
        },
        auth=auth,
        count=len(items),
    )


@app.get("/v1/cn/sentiment")
def cn_sentiment(date: Optional[str] = None, auth: dict = Depends(require_key)):
    """情绪温度/涨跌分布/涨停统计。"""
    _require_market(auth, "cn")
    day = _cn_asof_day(date)
    hot = _redis_get("qh:cn:sentiment")
    if hot and (_hot_day(hot) == day or (not date and _hot_day(hot) in {day, time.strftime("%Y-%m-%d")})):
        if _hot_day(hot) != day:
            hot = {**hot, "date": day, "asof_date": day}
        return ok(hot, auth=auth, src=hot.get("src") or "redis", date=day)
    cold = _read_json(SENTIMENT_DIR / f"{day}.json")
    if cold and cold.get("data"):
        return ok(cold.get("data"), auth=auth, src=cold.get("src") or "cold", date=day)
    # 兼容：情绪嵌在涨停日包里
    lu = _read_json(LIMIT_UP_DIR / f"{day}.json")
    if lu and lu.get("sentiment"):
        return ok(lu.get("sentiment"), auth=auth, src=lu.get("src") or "cold", date=day)
    raise HTTPException(404, detail={"code": 404, "message": f"no sentiment for {day}"})


@app.get("/v1/cn/lhb")
def cn_lhb(date: Optional[str] = None, auth: dict = Depends(require_key)):
    _require_market(auth, "cn")
    # 超管也明确未落地（不是权限问题）
    raise HTTPException(501, detail={"code": 501, "message": "lhb not available yet"})


@app.get("/v1/cn/sectors")
def cn_sectors(
    date: Optional[str] = None,
    kind: str = Query(
        "all",
        description="all|rise|fall|top|bottom|themes — 涨速/跌速/强弱榜/主题",
    ),
    auth: dict = Depends(require_key),
):
    """板块排名：优先 Redis 热缓存，其次日冷库。盘中以热数据为准。"""
    _require_market(auth, "cn")
    day = _cn_asof_day(date)
    body: Optional[dict] = None
    src_hint = "redis"
    hot = _redis_get("qh:cn:sectors")
    if hot and (_hot_day(hot) == day or (not date and _hot_day(hot) in {day, time.strftime("%Y-%m-%d")})):
        body = hot
        if _hot_day(body) != day:
            body = {**body, "date": day, "asof_date": day}
    if not body:
        cold = _read_json(SECTOR_DIR / f"{day}.json")
        if cold:
            body = cold
            src_hint = cold.get("src") or "cold"
    if not body:
        raise HTTPException(404, detail={"code": 404, "message": f"no sectors for {day}"})

    k = (kind or "all").strip().lower()
    if k == "all":
        data = body
    elif k in {"rise", "fall", "top", "bottom", "themes"}:
        data = {
            "date": body.get("date") or day,
            "ts": body.get("ts"),
            "src": body.get("src"),
            "asof_date": body.get("asof_date") or day,
            k: body.get(k) or [],
        }
    else:
        raise HTTPException(400, detail={"code": 400, "message": "kind must be all|rise|fall|top|bottom|themes"})

    count = 0
    for key in ("rise", "fall", "top", "bottom", "themes"):
        if isinstance(data.get(key), list):
            count += len(data[key])
    return ok(data, auth=auth, src=body.get("src") or src_hint, count=count)


@app.get("/v1/cn/moneyflow")
def cn_moneyflow(
    symbols: str = Query(..., description="逗号分隔代码，最多 batch_limit"),
    date: Optional[str] = None,
    auth: dict = Depends(require_key),
):
    """个股资金流：优先 Redis 热键，其次当日冷库 map。盘中以热数据为准。"""
    _require_market(auth, "cn")
    day = (date or time.strftime("%Y-%m-%d")).strip()
    today = time.strftime("%Y-%m-%d")
    cap = _batch_cap(auth)
    syms = [_norm_cn(x) for x in symbols.split(",") if x.strip()][:cap]
    cold = _read_json(MONEYFLOW_DIR / f"{day}.json")
    cold_map: dict = {}
    cold_src = "cold"
    if cold and isinstance(cold.get("items"), dict):
        cold_map = cold["items"]
        cold_src = cold.get("src") or "cold"

    out = []
    for sym in syms:
        row = None
        src = None
        if day == today:
            row = _redis_get(f"qh:cn:moneyflow:{sym}")
            if row:
                src = row.get("src") or "redis"
        if not row:
            row = cold_map.get(sym)
            if row:
                src = cold_src
        if not row:
            out.append({"symbol": sym, "date": day, "error": "not_found"})
            continue
        item = dict(row)
        item["symbol"] = item.get("symbol") or sym
        if src:
            item["src"] = src
        out.append(item)
    return ok(out, auth=auth, count=len(out), date=day)


@app.get("/v1/cn/indices")
def cn_indices(auth: dict = Depends(require_key)):
    _require_market(auth, "cn")
    # 用指数代码若已在 cn_daily；否则返回占位说明
    idxs = ["000001.SS", "399001.SZ", "399006.SZ"]
    out = []
    for sym in idxs:
        d = _read_json(CN_DIR / f"{sym}.json")
        bars = (d or {}).get("bars") or []
        if bars:
            last = bars[-1]
            out.append({"symbol": sym, "price": last.get("close"), "date": last.get("date")})
    return ok(out, auth=auth, count=len(out))


@app.exception_handler(HTTPException)
async def http_exc_handler(_, exc: HTTPException):
    detail = exc.detail if isinstance(exc.detail, dict) else {"code": exc.status_code, "message": str(exc.detail)}
    if isinstance(detail, dict) and "message" in detail:
        detail = {**detail, "message": scrub_message(str(detail.get("message") or ""))}
    return JSONResponse(status_code=exc.status_code, content=detail)
