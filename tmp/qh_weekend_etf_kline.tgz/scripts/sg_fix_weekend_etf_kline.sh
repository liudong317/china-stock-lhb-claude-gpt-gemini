#!/bin/bash
# 休市日回落 + ETF 热池 + 期货日K 补齐（仅 /www/wwwroot/caijing）
set -euo pipefail
WEB=/www/wwwroot/caijing
if [ -z "${WEB:-}" ] || [ ! -d "$WEB" ]; then
  echo WEB_INVALID
  exit 1
fi
cd "$WEB"

TGZ="${WEB}/qh_weekend_etf_kline.tgz"
PACK_URL="${PACK_URL:-https://raw.githubusercontent.com/liudong317/china-stock-lhb-claude-gpt-gemini/main/tmp/qh_weekend_etf_kline.tgz}"
if [ ! -f "$TGZ" ] || [ "${FORCE_DOWNLOAD:-1}" = "1" ]; then
  curl -fsSL -o "$TGZ" "$PACK_URL"
fi
tar -xzf "$TGZ" -C "$WEB"
echo extracted_tgz
# 部署脚本自身若尚未在包内，用仓库内已解压版本继续

test -f "$WEB/app/main.py"
test -f "$WEB/lib/trading_session.py"
test -f "$WEB/workers/sina_cn_quote_worker.py"
test -f "$WEB/scripts/sg_cn_futures_sina_append.py"

# 清已交割脏热（若存在）
redis-cli DEL 'qh:quote:cnf:au2510' 'qh:quote:cnf:AU2510' >/dev/null 2>&1 || true

# 重启 API + 相关 Worker（不碰其他站点）
systemctl restart qinghong-market-api.service 2>/dev/null \
  || systemctl restart qh-market-api.service 2>/dev/null \
  || true
systemctl restart qh-cn-quote-worker.service 2>/dev/null \
  || systemctl restart qinghong-cn-quote-worker.service 2>/dev/null \
  || true
systemctl restart qh-xuangutong-pool-worker.service 2>/dev/null || true
systemctl restart qh-xuangutong-sector-flow-worker.service 2>/dev/null || true

# 强制刷一轮池/板块（会话日=上一交易日）
export REDIS_URL="${REDIS_URL:-redis://127.0.0.1:6379/0}"
"$WEB/.venv/bin/python" "$WEB/workers/xuangutong_cn_pool_worker.py" --once --force \
  >>"$WEB/logs/pool_weekend_fix.log" 2>&1 || true
"$WEB/.venv/bin/python" "$WEB/workers/xuangutong_cn_sector_flow_worker.py" --once --force --skip-flow \
  >>"$WEB/logs/sector_weekend_fix.log" 2>&1 || true

# 先落本地已验通的优先冷库（末日到 7/31），再后台全量扩
COLD_URL="${COLD_URL:-https://raw.githubusercontent.com/liudong317/china-stock-lhb-claude-gpt-gemini/main/tmp/qh_cnf_pri_cold.tgz}"
curl -fsSL -o /tmp/qh_cnf_pri_cold.tgz "$COLD_URL" && tar -xzf /tmp/qh_cnf_pri_cold.tgz -C "$WEB" && echo cold_pri_ok || echo cold_pri_skip

PRI=scm,jmm,aum,rbm,IFM,IF2609,sc2609,jm2609,au2608,au2610,rb2609
nohup "$WEB/.venv/bin/python" "$WEB/scripts/sg_cn_futures_sina_append.py" \
  --symbols "$PRI" --force --sleep 0.15 \
  >>"$WEB/logs/cnf_sina_append_pri.log" 2>&1 &
echo "pri_append_pid=$!"

nohup "$WEB/.venv/bin/python" "$WEB/scripts/sg_cn_futures_sina_append.py" \
  --min-last 2026-07-31 --force --sleep 0.18 \
  >>"$WEB/logs/cnf_sina_append_all.log" 2>&1 &
echo "all_append_pid=$!"

sleep 8
grep -n "code_rev\|cn_session\|511880\|_cn_asof_day" "$WEB/app/main.py" | head -20
echo DEPLOY_OK
