#!/usr/bin/env python3
"""国内期货日 K 增量补齐：akshare 新浪 → merge 冷库，不覆盖全历史。

根因：旧 IndexService JSON 接口末日停在约 2024；akshare.futures_zh_daily_sina 可到最近交易日。
仅追加/覆盖同日 bar，保留既有字段与更长历史。

用法：
  .venv/bin/python scripts/sg_cn_futures_sina_append.py --min-last 2026-07-31 --sleep 0.2
  .venv/bin/python scripts/sg_cn_futures_sina_append.py --symbols scm,jmm,sc2609,IF2609 --force
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from lib.trading_session import cn_session_ymd, should_pull  # noqa: E402

LIST = ROOT / "data" / "lists" / "cn_futures.json"
OUT = ROOT / "data" / "raw" / "cn_futures_daily"
PROG = OUT / "_progress_sina_append.json"


def to_sina_candidates(sym: str) -> list[str]:
    """文件名/列表符号 → 新浪日 K 候选。"""
    s = (sym or "").strip()
    out: list[str] = []
    if not s:
        return out
    # 主连 rbm/IFM/scm → RB0/IF0/SC0
    if re.fullmatch(r"[A-Za-z]+[mM]", s):
        out.append(s[:-1].upper() + "0")
    # 月合约 sc2609 / IF2609 / 郑商所三位 SA609
    m3 = re.fullmatch(r"([A-Za-z]+)(\d{3})", s)
    if m3:
        root, yym = m3.group(1), m3.group(2)
        four = f"{root.upper()}2{yym[0]}{yym[1:]}"
        out.extend([four, four.lower(), s.upper(), s.lower()])
    if re.fullmatch(r"[A-Za-z]+\d{4}", s):
        out.extend([s, s.lower(), s.upper()])
    out.extend([s, s.upper(), s.lower()])
    seen: set[str] = set()
    uniq: list[str] = []
    for x in out:
        if x and x not in seen:
            seen.add(x)
            uniq.append(x)
    return uniq


def last_bar_date(path: Path) -> str:
    if not path.exists():
        return ""
    try:
        bars = json.loads(path.read_text(encoding="utf-8")).get("bars") or []
        if not bars:
            return ""
        return str(bars[-1].get("date") or "")[:10]
    except Exception:
        return ""


def pull_bars(sina_sym: str) -> list[dict]:
    import akshare as ak

    df = ak.futures_zh_daily_sina(symbol=sina_sym)
    if df is None or len(df) == 0:
        raise RuntimeError("empty")
    bars: list[dict] = []
    for _, row in df.iterrows():
        bars.append(
            {
                "date": str(row["date"])[:10],
                "open": float(row["open"]),
                "high": float(row["high"]),
                "low": float(row["low"]),
                "close": float(row["close"]),
                "volume": float(row.get("volume") or 0),
                "hold": float(row["hold"]) if "hold" in row and row["hold"] == row["hold"] else None,
                "settle": float(row["settle"]) if "settle" in row and row["settle"] == row["settle"] else None,
            }
        )
    return bars


def merge_write(path: Path, meta: dict, bars: list[dict], sina: str) -> tuple[int, str]:
    by: dict[str, dict] = {}
    if path.exists():
        try:
            old = json.loads(path.read_text(encoding="utf-8"))
            for b in old.get("bars") or []:
                d = str(b.get("date") or "")[:10]
                if d:
                    by[d] = b
            for k in ("secid", "name", "kind"):
                if not meta.get(k) and old.get(k) is not None:
                    meta[k] = old.get(k)
        except Exception:
            pass
    for b in bars:
        d = str(b.get("date") or "")[:10]
        if not d:
            continue
        prev = by.get(d) or {}
        # 保留旧 amount 等扩展字段，用新 OHLC 覆盖
        merged = {**prev, **{k: v for k, v in b.items() if v is not None}}
        by[d] = merged
    ordered = [by[k] for k in sorted(by)]
    payload = {
        "symbol": meta.get("symbol") or path.stem,
        "sina": sina,
        "secid": meta.get("secid"),
        "name": meta.get("name"),
        "kind": meta.get("kind"),
        "source": "akshare.futures_zh_daily_sina+merge",
        "bars": ordered,
        "n": len(ordered),
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    last = ordered[-1]["date"] if ordered else ""
    return len(ordered), last


def load_targets(symbols_arg: str, min_last: str, only_stale: bool) -> list[dict]:
    by_sym: dict[str, dict] = {}
    if LIST.exists():
        for s in json.loads(LIST.read_text(encoding="utf-8")).get("symbols") or []:
            sym = s.get("symbol")
            if sym:
                by_sym[sym] = s
                by_sym.setdefault(sym.lower(), {**s, "symbol": sym.lower()})
                by_sym.setdefault(sym.upper(), {**s, "symbol": sym.upper()})
    # 冷库已有文件也纳入（列表可能缺小写月合约）
    for p in OUT.glob("*.json"):
        if p.name.startswith("_"):
            continue
        stem = p.stem
        by_sym.setdefault(stem, {"symbol": stem, "kind": "file"})

    if symbols_arg:
        want = [x.strip() for x in symbols_arg.split(",") if x.strip()]
        targets = []
        for w in want:
            meta = by_sym.get(w) or by_sym.get(w.lower()) or by_sym.get(w.upper()) or {"symbol": w}
            targets.append(meta)
        return targets

    targets = []
    seen: set[str] = set()
    for sym, meta in by_sym.items():
        # 只跑「文件实际存在」或列表主连/月合约正名字段
        path = OUT / f"{meta.get('symbol')}.json"
        alt = None
        for cand in (sym, sym.lower(), sym.upper()):
            if (OUT / f"{cand}.json").exists():
                alt = cand
                break
        if alt:
            meta = {**meta, "symbol": alt}
            path = OUT / f"{alt}.json"
        key = meta["symbol"]
        if key in seen:
            continue
        # 跳过东财连续数字废码（无新浪映射价值）
        if re.fullmatch(r"\d{6}", key):
            continue
        seen.add(key)
        last = last_bar_date(path)
        if only_stale and min_last and last and last >= min_last:
            continue
        targets.append(meta)
    # 优先：主连 + 近月字母合约
    def rank(m: dict) -> tuple:
        s = m.get("symbol") or ""
        k = m.get("kind") or ""
        pri = 0 if k == "main" else 1 if re.search(r"[A-Za-z]+\d{3,4}$", s) else 2
        return (pri, s)

    targets.sort(key=rank)
    return targets


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default="", help="逗号分隔，优先这些")
    ap.add_argument("--min-last", default="", help="末日早于此才补；默认=会话日")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--sleep", type=float, default=0.22)
    ap.add_argument("--force", action="store_true", help="忽略交易日闸门")
    ap.add_argument("--all", action="store_true", help="不按 stale 过滤，全量 merge")
    args = ap.parse_args()

    ok_gate, reason = should_pull("cn_futures")
    if not ok_gate and not args.force:
        print(f"skip gate={reason} (use --force on weekend)", flush=True)
        return

    min_last = (args.min_last or cn_session_ymd()).strip()[:10]
    targets = load_targets(args.symbols, min_last, only_stale=not args.all)
    if args.limit:
        targets = targets[: args.limit]

    stats = {
        "ok": 0,
        "fail": 0,
        "skip": 0,
        "todo": len(targets),
        "min_last": min_last,
        "errors": [],
    }
    print(f"sina_append todo={len(targets)} min_last={min_last}", flush=True)

    for i, meta in enumerate(targets, 1):
        sym = meta["symbol"]
        path = OUT / f"{sym}.json"
        last = last_bar_date(path)
        if not args.all and not args.symbols and last and last >= min_last:
            stats["skip"] += 1
            continue
        done = False
        last_err = None
        for cand in to_sina_candidates(sym):
            try:
                bars = pull_bars(cand)
                n, new_last = merge_write(path, meta, bars, cand)
                stats["ok"] += 1
                print(f"[{i}/{len(targets)}] OK {sym} via {cand} n={n} last={new_last} was={last}", flush=True)
                done = True
                break
            except Exception as e:
                last_err = str(e)[:120]
                time.sleep(0.08)
        if not done:
            stats["fail"] += 1
            stats["errors"].append({"symbol": sym, "err": last_err})
            stats["errors"] = stats["errors"][-50:]
            print(f"[{i}/{len(targets)}] FAIL {sym} {last_err}", flush=True)
        if i % 20 == 0:
            PROG.write_text(json.dumps(stats, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        time.sleep(args.sleep)

    PROG.write_text(json.dumps(stats, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(stats, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
