# 交易时段 / 交易日判断（四市场）
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from functools import lru_cache
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
CAL_DIR = ROOT / "data" / "calendars"

TZ_CN = ZoneInfo("Asia/Shanghai")
TZ_US = ZoneInfo("America/New_York")


def _load_ymd_set(name: str) -> set[str]:
    p = CAL_DIR / name
    if not p.exists():
        return set()
    out: set[str] = set()
    for ln in p.read_text(encoding="utf-8").splitlines():
        s = ln.strip()
        if not s or s.startswith("#"):
            continue
        out.add(s[:10])
    return out


@lru_cache(maxsize=1)
def cn_holidays() -> set[str]:
    return _load_ymd_set("cn_holidays.txt")


@lru_cache(maxsize=1)
def us_holidays() -> set[str]:
    return _load_ymd_set("us_holidays.txt")


def _ymd(d: date) -> str:
    return d.isoformat()


def is_cn_trading_day(d: Optional[date] = None) -> bool:
    """A股 / 国内期货：工作日且非国内休市。"""
    d = d or datetime.now(TZ_CN).date()
    if d.weekday() >= 5:
        return False
    return _ymd(d) not in cn_holidays()


def prev_cn_trading_day(d: Optional[date] = None) -> date:
    """严格早于 d 的最近 A 股/国内期货交易日。"""
    cur = (d or datetime.now(TZ_CN).date()) - timedelta(days=1)
    for _ in range(45):
        if is_cn_trading_day(cur):
            return cur
        cur -= timedelta(days=1)
    return cur


def cn_session_date(d: Optional[date] = None) -> date:
    """会话归属日：交易日=当日；周末/假日=上一交易日（复盘/池子/情绪用）。"""
    d = d or datetime.now(TZ_CN).date()
    if is_cn_trading_day(d):
        return d
    return prev_cn_trading_day(d)


def cn_session_ymd(d: Optional[date] = None) -> str:
    return _ymd(cn_session_date(d))


def is_us_trading_day(d: Optional[date] = None) -> bool:
    """美股：美东工作日且非美股休市。"""
    d = d or datetime.now(TZ_US).date()
    if d.weekday() >= 5:
        return False
    return _ymd(d) not in us_holidays()


def is_futures_trading_day(now: Optional[datetime] = None) -> bool:
    """外盘期货（CME 等）：周日晚～周五美东；周六全天休；美股假日多数休（简化）。

    规则：美东周六 → 否；周日 18:00 前 → 否；其余看是否落在「周五收盘后～周日开盘前」空窗。
    """
    now = now or datetime.now(TZ_US)
    if now.tzinfo is None:
        now = now.replace(tzinfo=TZ_US)
    else:
        now = now.astimezone(TZ_US)
    wd = now.weekday()  # Mon=0 ... Sun=6
    t = now.time()
    if wd == 5:  # Saturday
        return False
    if wd == 6:  # Sunday — 约 18:00 ET 起活跃
        return t >= time(18, 0)
    if wd == 4 and t >= time(17, 0):  # Friday after ~17 ET 多数能源休息到周日
        return False
    # Mon-Thu 全天 + Fri 17 前；若当日是美股假日仍允许多数期货，但简化：假日也停日更、报价可开
    return True


def should_pull(market: str, *, now: Optional[datetime] = None) -> tuple[bool, str]:
    """日更/报价 Worker 统一闸门。返回 (可否拉, 原因)。"""
    m = market.lower().replace("-", "_")
    now_cn = now.astimezone(TZ_CN) if now and now.tzinfo else datetime.now(TZ_CN)
    now_us = now.astimezone(TZ_US) if now and now.tzinfo else datetime.now(TZ_US)

    if m in {"cn", "a", "ashare", "cn_stock"}:
        ok = is_cn_trading_day(now_cn.date())
        return ok, "cn_trading_day" if ok else "cn_non_trading_day"
    if m in {"cn_futures", "cnf", "domestic_futures"}:
        ok = is_cn_trading_day(now_cn.date())
        return ok, "cn_futures_trading_day" if ok else "cn_futures_non_trading_day"
    if m in {"us", "us_stock", "nasdaq", "nyse"}:
        ok = is_us_trading_day(now_us.date())
        return ok, "us_trading_day" if ok else "us_non_trading_day"
    if m in {"futures", "fut", "yahoo_futures", "overseas_futures"}:
        ok = is_futures_trading_day(now_us)
        return ok, "futures_session" if ok else "futures_closed"
    return False, f"unknown_market:{market}"


def sleep_until_next_check(seconds: float = 300.0) -> None:
    import time

    time.sleep(max(30.0, seconds))
